#!/usr/bin/env python

def test():
        print("Hello docker")

if __name__ == "__main__":
        test()
